package it.unibs.ing.fp.cartaalta;

/**
 * Classe Main.
 * 
 * @author Stefano Valloncini
 * @see <https://github.com/xStevatt/FondamentiDiProgrammazione>
 */
public class MainCartaAlta 
{
	public static void main(String[] args)
	{
		UIManager.mostraMenu();
	}
}
