package it.unibs.fp.lab.mylib;

/**
 * 
 * @author Stefano Valloncini
 * @see <https://github.com/xStevatt/FondamentiDiProgrammazione>
 */

public class NiceStrings 
{

}
